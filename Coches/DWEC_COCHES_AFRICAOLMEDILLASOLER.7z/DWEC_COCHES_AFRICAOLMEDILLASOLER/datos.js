/*En este archivo se encuntran los datos base que aparecen el la practica */




let porsche = new Marca("porsche");
let ferrari = new Marca("ferrari");
let ford = new Marca("ford");
let seat = new Marca("seat");
let renault = new Marca("renault");

porsche.addModelo("718 Boxster");
porsche.addModelo("18 Cayman");
porsche.addModelo("911");
porsche.addModelo("918 Spyder");
porsche.addModelo("Cayenne");
porsche.addModelo("Cayman");
porsche.addModelo("Macan");
porsche.addModelo("Panamera");


ferrari.addModelo("458");
ferrari.addModelo("488");
ferrari.addModelo("California T");
ferrari.addModelo("F12 Berlinetta");
ferrari.addModelo("FF");
ferrari.addModelo("Laferrari");
ferrari.addModelo("Portofino");

ford.addModelo("B-max");
ford.addModelo("C-max");
ford.addModelo("exosport");
ford.addModelo("edge");
ford.addModelo("fiesta");
ford.addModelo("focus");
ford.addModelo("galaxy");
ford.addModelo("ka+");
ford.addModelo("kuga");
ford.addModelo("mondeo");
ford.addModelo("mustang");
ford.addModelo("ranger");
ford.addModelo("s-max");
ford.addModelo("tourneo connect");
ford.addModelo("tourneo custom");

seat.addModelo("alhambra");
seat.addModelo("altea");
seat.addModelo("arona");
seat.addModelo("ateca");
seat.addModelo("ibiza");
seat.addModelo("leon");
seat.addModelo("mii");
seat.addModelo("toledo");

renault.addModelo("captur");
renault.addModelo("clio");
renault.addModelo("espace");
renault.addModelo("fluence");
renault.addModelo("kadjar");
renault.addModelo("kangoo");
renault.addModelo("koleos");
renault.addModelo("laguna");
renault.addModelo("mégane");
renault.addModelo("scénic");
renault.addModelo("talismán");
renault.addModelo("trafic");
renault.addModelo("twingo");
renault.addModelo("twizy");
renault.addModelo("zoe");
